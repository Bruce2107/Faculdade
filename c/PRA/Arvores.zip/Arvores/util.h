#include <stdio.h>
#include <stdlib.h>

int * generateRandomArray(int size);
int * generateOrderedArray(int n);
int * generateOrderedArrayDescending(int n);